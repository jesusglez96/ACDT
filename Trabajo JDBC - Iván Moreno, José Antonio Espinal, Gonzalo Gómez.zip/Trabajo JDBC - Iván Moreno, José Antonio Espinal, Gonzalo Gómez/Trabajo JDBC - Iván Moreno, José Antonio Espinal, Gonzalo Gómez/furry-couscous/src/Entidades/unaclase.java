package Entidades;

public class unaclase {
}
