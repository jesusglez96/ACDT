use ApuestasDeportivas
go

select * from Apuestas
select * from ApuestaTipo2
insert into ApuestaTipo2(id, equipo, goles)
values('9A04FEB6-05B3-463A-90A8-0955AB39496A', 'visitante',1)

