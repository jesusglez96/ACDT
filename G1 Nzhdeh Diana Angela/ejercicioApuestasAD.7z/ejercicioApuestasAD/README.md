# ejercicioApuestasAD
Ejercicio de apuestas del módulo Acceso a Datos.
